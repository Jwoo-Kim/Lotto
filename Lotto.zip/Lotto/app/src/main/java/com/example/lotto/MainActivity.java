package com.example.lotto;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class MainActivity extends AppCompatActivity {

    LottieAnimationView lotteryButton;
    TextView number1;
    TextView number2;
    TextView number3;
    TextView number4;
    TextView number5;
    TextView number6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CountDownTimer countDownTimer;

        number1 = (TextView) findViewById(R.id.number1);
        number2 = (TextView) findViewById(R.id.number2);
        number3 = (TextView) findViewById(R.id.number3);
        number4 = (TextView) findViewById(R.id.number4);
        number5 = (TextView) findViewById(R.id.number5);
        number6 = (TextView) findViewById(R.id.number6);

        int[] numbers = new int[6];
        countDownTimer = new CountDownTimer(3000, 100) {
            @Override
            public void onTick(long millisUntilFinished) {
                for (int i = 0; i< 6; i++) {
                    // 번호생성
                    numbers[i] = (int)(Math.random()*45) + 1;

                    // 중복 번호 제거
                    for(int j = 0; j < i; j++) {
                        if(numbers[i] == numbers[j]) {
                            i--;
                            break;
                        }
                    }
                }
                number1.setText(String.valueOf(numbers[0]));
                number2.setText(String.valueOf(numbers[1]));
                number3.setText(String.valueOf(numbers[2]));
                number4.setText(String.valueOf(numbers[3]));
                number5.setText(String.valueOf(numbers[4]));
                number6.setText(String.valueOf(numbers[5]));
            }

            @Override
            public void onFinish() {
            }
        };


        lotteryButton = (LottieAnimationView) findViewById(R.id.lotteryButton);
        lotteryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lotteryButton.isAnimating()) {
                    lotteryButton.cancelAnimation();
                    countDownTimer.cancel();
                } else {
                    lotteryButton.playAnimation();
                    countDownTimer.start();
                }
            }
        });
    }
}